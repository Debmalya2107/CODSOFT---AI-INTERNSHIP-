 const CVData = {
        personal: {
          fullName: "",
          jobTitle: "",
          email: "",
          phone: "",
          location: "",
          linkedin: "",
          photo: null,
          summary: "",
        },
        experience: [],
        education: [],
        skills: [],
        languages: [],
        projects: [],
        certifications: [],
        settings: {
          template: "silicon-valley",
          primaryColor: "#4f46e5",
          fontPairing: "modern",
          lineSpacing: 1.6,
          margins: 30,
          showPhoto: true,
          showProjects: true,
          showCertifications: true,
          showLanguages: true,
        },
      };

      // Smart Content Suggestions Database
      const SmartSuggestions = {
        summaries: {
          "project manager": [
            "Results-driven Project Manager with 5+ years of experience leading cross-functional teams and delivering complex projects on time and within budget. Proven track record of managing budgets exceeding $500K and improving team efficiency by 30%.",
            "Strategic Project Manager specializing in Agile methodologies and stakeholder management. Expert in risk mitigation, resource allocation, and driving organizational transformation initiatives across enterprise-level projects.",
            "Dynamic Project Manager with expertise in software development lifecycle and product launches. Successfully managed 20+ projects with 95% on-time delivery rate, consistently exceeding stakeholder expectations.",
          ],
          "software engineer": [
            "Innovative Software Engineer with 4+ years of experience building scalable web applications. Proficient in modern JavaScript frameworks (React, Node.js) and cloud technologies (AWS, Docker). Contributed to products serving 1M+ users.",
            "Full-Stack Software Engineer specializing in microservices architecture and API development. Strong background in system design, performance optimization, and agile development practices. Reduced application load time by 40%.",
            "Passionate Software Engineer focused on clean code and user-centric design. Expert in React, TypeScript, and RESTful APIs. Successfully launched 15+ features that increased user engagement by 25%.",
          ],
          "data scientist": [
            "Data Scientist with expertise in machine learning, predictive modeling, and big data analytics. Developed ML models that improved business KPIs by 35%. Proficient in Python, R, TensorFlow, and SQL.",
            "Analytical Data Scientist specializing in NLP and computer vision applications. Published research in top-tier conferences. Built production-grade ML pipelines processing 10M+ records daily.",
            "Results-oriented Data Scientist with strong statistical background and business acumen. Created data-driven insights that generated $2M in additional revenue. Expert in A/B testing and experimentation.",
          ],
          "marketing manager": [
            "Strategic Marketing Manager with 6+ years driving brand growth and customer acquisition. Launched campaigns generating 50% increase in qualified leads. Expert in digital marketing, SEO, and marketing automation.",
            "Growth-focused Marketing Manager specializing in B2B SaaS and content strategy. Scaled marketing operations from $500K to $5M ARR. Proficient in HubSpot, Google Analytics, and marketing attribution.",
            "Creative Marketing Manager with proven track record in brand positioning and multi-channel campaigns. Increased social media engagement by 200% and improved conversion rates by 35%.",
          ],
          designer: [
            "Award-winning Product Designer with 5+ years crafting intuitive user experiences for web and mobile applications. Led design systems that improved development velocity by 40%. Expert in Figma, Sketch, and prototyping.",
            "User-centric UX/UI Designer passionate about accessibility and inclusive design. Conducted 100+ user research sessions resulting in 60% increase in user satisfaction. Proficient in design thinking and usability testing.",
            "Creative Designer specializing in brand identity and visual storytelling. Delivered design solutions for Fortune 500 clients. Strong skills in Adobe Creative Suite, motion graphics, and design strategy.",
          ],
          default: [
            "Accomplished professional with proven track record of driving results and exceeding expectations. Strong analytical and problem-solving skills combined with excellent communication and leadership abilities.",
            "Dedicated and results-oriented professional with expertise in [your field]. Demonstrated ability to manage multiple priorities, collaborate with cross-functional teams, and deliver high-quality outcomes.",
            "Motivated professional with strong background in [your industry]. Committed to continuous learning and professional development. Known for exceptional work ethic and attention to detail.",
          ],
        },

        experienceBullets: {
          "project manager": [
            "Led cross-functional team of 10+ members to deliver $2M+ projects on time with 98% customer satisfaction",
            "Implemented Agile methodologies reducing project delivery time by 30% and improving team productivity",
            "Managed project budgets exceeding $500K while maintaining 95% cost efficiency and zero budget overruns",
          ],
          "software engineer": [
            "Developed and deployed 15+ features using React and Node.js, serving 100K+ active users monthly",
            "Optimized database queries and API performance, reducing response time by 45% and server costs by $10K/year",
            "Collaborated with product team to architect scalable microservices handling 1M+ requests per day",
          ],
          "data scientist": [
            "Built machine learning models with 92% accuracy for customer churn prediction, saving $500K annually",
            "Analyzed 10M+ data points to uncover insights that informed strategic decisions and improved ROI by 25%",
            "Developed automated ETL pipelines processing 5TB of data daily, reducing manual effort by 80%",
          ],
          "marketing manager": [
            "Launched multi-channel campaigns generating 10K+ qualified leads and $3M in pipeline revenue",
            "Increased organic traffic by 150% through SEO optimization and content marketing strategy",
            "Managed $500K+ marketing budget across digital channels with 300% ROI and 25% lower CAC",
          ],
          designer: [
            "Designed user interfaces for mobile app with 4.8★ rating and 500K+ downloads on App Store",
            "Created comprehensive design system reducing design-to-development time by 40%",
            "Conducted user research with 50+ participants leading to 35% increase in user engagement",
          ],
          default: [
            "Successfully managed and executed projects resulting in measurable improvements to key business metrics",
            "Collaborated with stakeholders across multiple departments to achieve organizational objectives",
            "Implemented innovative solutions that increased efficiency and reduced operational costs",
          ],
        },
      };

      // ATS Keywords Database (common across industries)
      const ATSKeywords = {
        technical: [
          "python",
          "javascript",
          "java",
          "react",
          "node.js",
          "angular",
          "vue",
          "typescript",
          "html",
          "css",
          "sql",
          "mongodb",
          "postgresql",
          "aws",
          "azure",
          "gcp",
          "docker",
          "kubernetes",
          "git",
          "ci/cd",
          "agile",
          "scrum",
          "jira",
          "rest api",
          "graphql",
          "machine learning",
          "data analysis",
          "excel",
          "tableau",
          "power bi",
          "salesforce",
        ],
        soft: [
          "leadership",
          "communication",
          "teamwork",
          "problem solving",
          "critical thinking",
          "project management",
          "time management",
          "collaboration",
          "adaptability",
          "creativity",
          "analytical",
          "strategic planning",
          "stakeholder management",
          "presentation",
          "negotiation",
        ],
        business: [
          "budget management",
          "revenue growth",
          "cost reduction",
          "roi",
          "kpi",
          "metrics",
          "strategy",
          "operations",
          "process improvement",
          "risk management",
          "compliance",
          "vendor management",
          "customer success",
          "business development",
          "market analysis",
        ],
      };

      // Data Management Functions
      const DataManager = {
        // Save data to localStorage
        save: function () {
          try {
            localStorage.setItem("debdex_cv_data", JSON.stringify(CVData));
            return true;
          } catch (e) {
            console.error("Failed to save data:", e);
            return false;
          }
        },

        // Load data from localStorage
        load: function () {
          try {
            const saved = localStorage.getItem("debdex_cv_data");
            if (saved) {
              const parsed = JSON.parse(saved);
              Object.assign(CVData, parsed);
              return true;
            }
          } catch (e) {
            console.error("Failed to load data:", e);
          }
          return false;
        },

        // Export to JSON file
        exportJSON: function () {
          const dataStr = JSON.stringify(CVData, null, 2);
          const dataBlob = new Blob([dataStr], { type: "application/json" });
          const url = URL.createObjectURL(dataBlob);
          const link = document.createElement("a");
          link.href = url;
          link.download = `debdex-cv-${
            CVData.personal.fullName.replace(/\s+/g, "-").toLowerCase() ||
            "export"
          }-${Date.now()}.json`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        },

        // Import from JSON file
        importJSON: function (file) {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = function (e) {
              try {
                const imported = JSON.parse(e.target.result);
                // Validate structure
                if (imported.personal && imported.settings) {
                  Object.assign(CVData, imported);
                  DataManager.save();
                  resolve(imported);
                } else {
                  reject(new Error("Invalid JSON structure"));
                }
              } catch (error) {
                reject(error);
              }
            };
            reader.onerror = reject;
            reader.readAsText(file);
          });
        },

        // Get smart suggestions
        getSuggestions: function (type, jobTitle) {
          const title = jobTitle.toLowerCase();
          const suggestions = SmartSuggestions[type];

          // Try to find exact match
          if (suggestions[title]) {
            return suggestions[title];
          }

          // Try to find partial match
          for (const key in suggestions) {
            if (title.includes(key) || key.includes(title)) {
              return suggestions[key];
            }
          }

          // Return default
          return suggestions["default"] || [];
        },

        // ATS Analysis
        analyzeATS: function (jobDescription) {
          const cvText = this.getCVText().toLowerCase();
          const jdText = jobDescription.toLowerCase();

          // Extract keywords from job description
          const jdWords = jdText
            .replace(/[^\w\s-]/g, " ")
            .split(/\s+/)
            .filter((word) => word.length > 3);

          // Get unique keywords
          const jdKeywords = [...new Set(jdWords)];

          // Common stop words to filter
          const stopWords = [
            "this",
            "that",
            "with",
            "from",
            "have",
            "will",
            "your",
            "their",
            "about",
            "which",
            "were",
            "been",
            "other",
            "into",
            "through",
          ];

          // Filter keywords
          const filteredKeywords = jdKeywords.filter(
            (kw) => !stopWords.includes(kw)
          );

          // Check matches
          const matched = [];
          const missing = [];

          filteredKeywords.forEach((keyword) => {
            if (cvText.includes(keyword)) {
              matched.push(keyword);
            } else {
              missing.push(keyword);
            }
          });

          // Calculate score
          const score =
            filteredKeywords.length > 0
              ? Math.round((matched.length / filteredKeywords.length) * 100)
              : 0;

          // Generate recommendations
          const recommendations = this.generateRecommendations(score, missing);

          return {
            score,
            matched: matched.slice(0, 20), // Limit display
            missing: missing.slice(0, 15),
            recommendations,
          };
        },

        getCVText: function () {
          let text = "";

          // Personal info
          text += CVData.personal.fullName + " ";
          text += CVData.personal.jobTitle + " ";
          text += CVData.personal.summary + " ";

          // Experience
          CVData.experience.forEach((exp) => {
            text += exp.title + " ";
            text += exp.company + " ";
            text += exp.description + " ";
          });

          // Education
          CVData.education.forEach((edu) => {
            text += edu.degree + " ";
            text += edu.institution + " ";
            text += edu.description + " ";
          });

          // Skills
          CVData.skills.forEach((skill) => {
            text += skill.name + " ";
          });

          // Projects
          CVData.projects.forEach((proj) => {
            text += proj.title + " ";
            text += proj.description + " ";
          });

          return text;
        },

        generateRecommendations: function (score, missing) {
          const recs = [];

          if (score < 50) {
            recs.push(
              "Your CV has a low match score. Consider incorporating more relevant keywords from the job description."
            );
          }

          if (missing.length > 10) {
            recs.push(
              `You're missing ${missing.length} key terms. Review the job description and update your experience section.`
            );
          }

          if (score >= 50 && score < 70) {
            recs.push(
              "Good foundation! Add a few more relevant skills and experiences to improve your match."
            );
          }

          if (score >= 70 && score < 85) {
            recs.push(
              "Strong match! Consider adding specific metrics or achievements related to the missing keywords."
            );
          }

          if (score >= 85) {
            recs.push(
              "Excellent match! Your CV aligns well with the job requirements."
            );
          }

          // Specific recommendations based on missing keywords
          const techKeywords = ATSKeywords.technical.filter((k) =>
            missing.includes(k)
          );
          if (techKeywords.length > 0) {
            recs.push(
              `Add technical skills: ${techKeywords.slice(0, 5).join(", ")}`
            );
          }

          const softKeywords = ATSKeywords.soft.filter((k) =>
            missing.includes(k)
          );
          if (softKeywords.length > 0) {
            recs.push(
              `Highlight soft skills: ${softKeywords.slice(0, 5).join(", ")}`
            );
          }

          return recs;
        },

        // Generate unique ID
        generateId: function () {
          return Date.now().toString(36) + Math.random().toString(36).substr(2);
        },
      };

      // Auto-save on data change (debounced)
      let saveTimeout;
      function autoSave() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          DataManager.save();
        }, 1000);
      }

      // Initialize: Load saved data on page load
      document.addEventListener("DOMContentLoaded", function () {
        DataManager.load();
      });
      /* ===================================
   DEBDEX ULTRA - UI MANAGEMENT
   DOM Manipulation and User Interactions
   =================================== */

      const UIManager = {
        // Initialize all UI components
        init: function () {
          this.setupWizardTabs();
          this.setupDarkMode();
          this.setupZoomControls();
          this.setupATSPanel();
          this.setupPhotoUpload();
          this.setupFormInputs();
          this.setupDynamicLists();
          this.setupMagicWand();
          this.setupTemplateSelection();
          this.setupCustomizer();
          this.renderPreview();
          this.loadSavedData();

          console.log("Debdex Ultra initialized ✨");
        },

        // Wizard Tab Navigation
        setupWizardTabs: function () {
          const tabs = document.querySelectorAll(".wizard-tab");
          const steps = document.querySelectorAll(".wizard-step");

          tabs.forEach((tab) => {
            tab.addEventListener("click", function () {
              const stepId = this.dataset.step;

              // Update active tab
              tabs.forEach((t) => t.classList.remove("active"));
              this.classList.add("active");

              // Update active step
              steps.forEach((s) => s.classList.remove("active"));
              document.getElementById(`step-${stepId}`).classList.add("active");
            });
          });
        },

        // Dark Mode Toggle
        setupDarkMode: function () {
          const toggle = document.getElementById("darkModeToggle");
          const icon = toggle.querySelector("i");

          toggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode");

            if (document.body.classList.contains("dark-mode")) {
              icon.classList.remove("fa-moon");
              icon.classList.add("fa-sun");
            } else {
              icon.classList.remove("fa-sun");
              icon.classList.add("fa-moon");
            }
          });
        },

        // Zoom Controls
        setupZoomControls: function () {
          const container = document.getElementById("previewContainer");
          const zoomLevel = document.getElementById("zoomLevel");
          let currentZoom = 100;

          document
            .getElementById("zoomIn")
            .addEventListener("click", function () {
              if (currentZoom < 120) {
                currentZoom = 120;
                container.dataset.zoom = "120";
                zoomLevel.textContent = "120%";
              }
            });

          document
            .getElementById("zoomOut")
            .addEventListener("click", function () {
              if (currentZoom > 80) {
                currentZoom = 80;
                container.dataset.zoom = "80";
                zoomLevel.textContent = "80%";
              }
            });

          document
            .getElementById("resetZoom")
            .addEventListener("click", function () {
              currentZoom = 100;
              container.dataset.zoom = "100";
              zoomLevel.textContent = "100%";
            });
        },

        // ATS Panel
        setupATSPanel: function () {
          const toggle = document.getElementById("atsToggle");
          const content = document.getElementById("atsContent");
          const analyzeBtn = document.getElementById("analyzeBtn");

          toggle.addEventListener("click", function () {
            content.classList.toggle("active");
          });

          analyzeBtn.addEventListener("click", function () {
            const jobDesc = document.getElementById("jobDescInput").value;
            if (!jobDesc.trim()) {
              alert("Please paste a job description first.");
              return;
            }

            UIManager.analyzeAndDisplayATS(jobDesc);
          });
        },

        analyzeAndDisplayATS: function (jobDescription) {
          const results = DataManager.analyzeATS(jobDescription);
          const resultsDiv = document.getElementById("atsResults");

          // Update score
          document.getElementById("scoreText").textContent =
            results.score + "%";

          // Animate score ring
          const scoreFill = document.getElementById("scoreRingFill");
          const circumference = 2 * Math.PI * 52; // radius = 52
          const offset = circumference - (results.score / 100) * circumference;
          scoreFill.style.strokeDashoffset = offset;

          // Update color based on score
          if (results.score >= 70) {
            scoreFill.style.stroke = "#10b981"; // Green
          } else if (results.score >= 50) {
            scoreFill.style.stroke = "#f59e0b"; // Orange
          } else {
            scoreFill.style.stroke = "#ef4444"; // Red
          }

          // Display matched keywords
          const matchedDiv = document.getElementById("matchedKeywords");
          matchedDiv.innerHTML = results.matched
            .map((kw) => `<span class="keyword-tag">${kw}</span>`)
            .join("");

          // Display missing keywords
          const missingDiv = document.getElementById("missingKeywords");
          missingDiv.innerHTML = results.missing
            .map((kw) => `<span class="keyword-tag missing">${kw}</span>`)
            .join("");

          // Display recommendations
          const recsDiv = document.getElementById("recommendationsList");
          recsDiv.innerHTML = results.recommendations
            .map((rec) => `<li>${rec}</li>`)
            .join("");

          // Show results
          resultsDiv.style.display = "block";
        },

        // Photo Upload with Canvas Processing
        setupPhotoUpload: function () {
          const input = document.getElementById("photoInput");
          const preview = document.getElementById("photoPreview");
          const canvas = document.getElementById("photoCanvas");
          const ctx = canvas.getContext("2d");

          input.addEventListener("change", function (e) {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function (event) {
              const img = new Image();
              img.onload = function () {
                // Set canvas size
                const size = 300;
                canvas.width = size;
                canvas.height = size;

                // Calculate crop dimensions (center crop)
                const scale = Math.max(size / img.width, size / img.height);
                const x = size / 2 - (img.width / 2) * scale;
                const y = size / 2 - (img.height / 2) * scale;

                // Draw and crop image
                ctx.drawImage(img, x, y, img.width * scale, img.height * scale);

                // Convert to data URL
                const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
                CVData.personal.photo = dataUrl;

                // Update preview
                preview.innerHTML = `<img src="${dataUrl}" alt="Profile Photo">`;

                autoSave();
                UIManager.renderPreview();
              };
              img.src = event.target.result;
            };
            reader.readAsDataURL(file);
          });
        },

        // Form Input Handlers
        setupFormInputs: function () {
          // Personal info inputs
          const personalFields = [
            "fullName",
            "jobTitle",
            "email",
            "phone",
            "location",
            "linkedin",
            "summary",
          ];

          personalFields.forEach((field) => {
            const input = document.getElementById(field);
            if (input) {
              input.addEventListener("input", function () {
                CVData.personal[field] = this.value;
                autoSave();
                UIManager.renderPreview();
              });
            }
          });
        },

        // Dynamic Lists (Experience, Education, Skills, etc.)
        setupDynamicLists: function () {
          // Experience
          document
            .getElementById("addExperience")
            .addEventListener("click", () => {
              this.addExperienceItem();
            });

          // Education
          document
            .getElementById("addEducation")
            .addEventListener("click", () => {
              this.addEducationItem();
            });

          // Skills
          document.getElementById("addSkill").addEventListener("click", () => {
            this.addSkillItem();
          });

          // Languages
          document
            .getElementById("addLanguage")
            .addEventListener("click", () => {
              this.addLanguageItem();
            });

          // Projects
          document
            .getElementById("addProject")
            .addEventListener("click", () => {
              this.addProjectItem();
            });

          // Certifications
          document
            .getElementById("addCertification")
            .addEventListener("click", () => {
              this.addCertificationItem();
            });

          // Setup Sortable
          this.setupSortable();
        },

        addExperienceItem: function (data = null) {
          const id = data?.id || DataManager.generateId();
          const item = data || {
            id,
            title: "",
            company: "",
            location: "",
            startDate: "",
            endDate: "",
            current: false,
            description: "",
          };

          if (!data) {
            CVData.experience.push(item);
          }

          const html = `
            <div class="sortable-item" data-id="${item.id}">
                <div class="sortable-item-header">
                    <i class="fas fa-grip-vertical drag-handle"></i>
                    <span class="sortable-item-title">Experience</span>
                    <div class="item-actions">
                        <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('experience', '${
                          item.id
                        }')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" placeholder="Job Title" value="${
                          item.title
                        }" 
                            onchange="UIManager.updateItem('experience', '${
                              item.id
                            }', 'title', this.value)">
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Company" value="${
                          item.company
                        }"
                            onchange="UIManager.updateItem('experience', '${
                              item.id
                            }', 'company', this.value)">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="date" placeholder="Start Date" value="${
                          item.startDate
                        }"
                            onchange="UIManager.updateItem('experience', '${
                              item.id
                            }', 'startDate', this.value)">
                    </div>
                    <div class="form-group">
                        <input type="date" placeholder="End Date" value="${
                          item.endDate
                        }" ${item.current ? "disabled" : ""}
                            onchange="UIManager.updateItem('experience', '${
                              item.id
                            }', 'endDate', this.value)">
                    </div>
                </div>
                <div class="form-group">
                    <label><input type="checkbox" ${
                      item.current ? "checked" : ""
                    } 
                        onchange="UIManager.toggleCurrent('experience', '${
                          item.id
                        }', this.checked)"> Currently working here</label>
                </div>
                <div class="form-group">
                    <button class="magic-wand" onclick="UIManager.showExperienceSuggestions('${
                      item.id
                    }')" title="Generate Smart Suggestions">
                        <i class="fas fa-magic"></i>
                    </button>
                    <textarea rows="4" placeholder="Describe your responsibilities and achievements..." 
                        onchange="UIManager.updateItem('experience', '${
                          item.id
                        }', 'description', this.value)">${
            item.description
          }</textarea>
                    <div class="suggestions" id="exp-suggestions-${
                      item.id
                    }" style="display: none;"></div>
                </div>
            </div>
        `;

          document
            .getElementById("experienceList")
            .insertAdjacentHTML("beforeend", html);
          autoSave();
        },

        addEducationItem: function (data = null) {
          const id = data?.id || DataManager.generateId();
          const item = data || {
            id,
            degree: "",
            institution: "",
            location: "",
            graduationDate: "",
            description: "",
          };

          if (!data) {
            CVData.education.push(item);
          }

          const html = `
            <div class="sortable-item" data-id="${item.id}">
                <div class="sortable-item-header">
                    <i class="fas fa-grip-vertical drag-handle"></i>
                    <span class="sortable-item-title">Education</span>
                    <div class="item-actions">
                        <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('education', '${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" placeholder="Degree" value="${item.degree}"
                            onchange="UIManager.updateItem('education', '${item.id}', 'degree', this.value)">
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Institution" value="${item.institution}"
                            onchange="UIManager.updateItem('education', '${item.id}', 'institution', this.value)">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" placeholder="Location" value="${item.location}"
                            onchange="UIManager.updateItem('education', '${item.id}', 'location', this.value)">
                    </div>
                    <div class="form-group">
                        <input type="date" placeholder="Graduation Date" value="${item.graduationDate}"
                            onchange="UIManager.updateItem('education', '${item.id}', 'graduationDate', this.value)">
                    </div>
                </div>
                <div class="form-group">
                    <textarea rows="3" placeholder="Additional details (honors, relevant coursework, etc.)"
                        onchange="UIManager.updateItem('education', '${item.id}', 'description', this.value)">${item.description}</textarea>
                </div>
            </div>
        `;

          document
            .getElementById("educationList")
            .insertAdjacentHTML("beforeend", html);
          autoSave();
        },

        addSkillItem: function () {
          const nameInput = document.getElementById("skillName");
          const levelInput = document.getElementById("skillLevel");

          const name = nameInput.value.trim();
          const level = parseInt(levelInput.value) || 80;

          if (!name) return;

          const id = DataManager.generateId();
          const skill = { id, name, level };
          CVData.skills.push(skill);

          this.renderSkillItem(skill);

          nameInput.value = "";
          levelInput.value = 80;
          autoSave();
          this.renderPreview();
        },

        renderSkillItem: function (skill) {
          const html = `
            <div class="skill-item" data-id="${skill.id}">
                <div class="skill-info">
                    <div class="skill-name">${skill.name}</div>
                    <div class="skill-bar">
                        <div class="skill-bar-fill" style="width: ${skill.level}%"></div>
                    </div>
                </div>
                <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('skills', '${skill.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
          document
            .getElementById("skillsList")
            .insertAdjacentHTML("beforeend", html);
        },

        addLanguageItem: function () {
          const nameInput = document.getElementById("languageName");
          const levelSelect = document.getElementById("languageLevel");

          const name = nameInput.value.trim();
          const level = levelSelect.value;

          if (!name) return;

          const id = DataManager.generateId();
          const language = { id, name, level };
          CVData.languages.push(language);

          this.renderLanguageItem(language);

          nameInput.value = "";
          autoSave();
          this.renderPreview();
        },

        renderLanguageItem: function (language) {
          const html = `
            <div class="skill-item" data-id="${language.id}">
                <div class="skill-info">
                    <div class="skill-name">${language.name}</div>
                    <small>${language.level}</small>
                </div>
                <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('languages', '${language.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
          document
            .getElementById("languagesList")
            .insertAdjacentHTML("beforeend", html);
        },

        addProjectItem: function (data = null) {
          const id = data?.id || DataManager.generateId();
          const item = data || {
            id,
            title: "",
            link: "",
            description: "",
          };

          if (!data) {
            CVData.projects.push(item);
          }

          const html = `
            <div class="sortable-item" data-id="${item.id}">
                <div class="sortable-item-header">
                    <i class="fas fa-grip-vertical drag-handle"></i>
                    <span class="sortable-item-title">Project</span>
                    <div class="item-actions">
                        <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('projects', '${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" placeholder="Project Title" value="${item.title}"
                        onchange="UIManager.updateItem('projects', '${item.id}', 'title', this.value)">
                </div>
                <div class="form-group">
                    <input type="url" placeholder="Project Link (optional)" value="${item.link}"
                        onchange="UIManager.updateItem('projects', '${item.id}', 'link', this.value)">
                </div>
                <div class="form-group">
                    <textarea rows="3" placeholder="Describe the project, your role, and impact..."
                        onchange="UIManager.updateItem('projects', '${item.id}', 'description', this.value)">${item.description}</textarea>
                </div>
            </div>
        `;

          document
            .getElementById("projectsList")
            .insertAdjacentHTML("beforeend", html);
          autoSave();
        },

        addCertificationItem: function (data = null) {
          const id = data?.id || DataManager.generateId();
          const item = data || {
            id,
            name: "",
            issuer: "",
            date: "",
          };

          if (!data) {
            CVData.certifications.push(item);
          }

          const html = `
            <div class="sortable-item" data-id="${item.id}">
                <div class="sortable-item-header">
                    <i class="fas fa-grip-vertical drag-handle"></i>
                    <span class="sortable-item-title">Certification</span>
                    <div class="item-actions">
                        <button class="btn-icon-sm delete" onclick="UIManager.deleteItem('certifications', '${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" placeholder="Certification Name" value="${item.name}"
                            onchange="UIManager.updateItem('certifications', '${item.id}', 'name', this.value)">
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Issuing Organization" value="${item.issuer}"
                            onchange="UIManager.updateItem('certifications', '${item.id}', 'issuer', this.value)">
                    </div>
                </div>
                <div class="form-group">
                    <input type="date" placeholder="Issue Date" value="${item.date}"
                        onchange="UIManager.updateItem('certifications', '${item.id}', 'date', this.value)">
                </div>
            </div>
        `;

          document
            .getElementById("certificationsList")
            .insertAdjacentHTML("beforeend", html);
          autoSave();
        },

        // Update, Delete, and Toggle methods
        updateItem: function (type, id, field, value) {
          const item = CVData[type].find((i) => i.id === id);
          if (item) {
            item[field] = value;
            autoSave();
            this.renderPreview();
          }
        },

        deleteItem: function (type, id) {
          CVData[type] = CVData[type].filter((i) => i.id !== id);
          document.querySelector(`[data-id="${id}"]`).remove();
          autoSave();
          this.renderPreview();
        },

        toggleCurrent: function (type, id, checked) {
          const item = CVData[type].find((i) => i.id === id);
          if (item) {
            item.current = checked;
            if (checked) {
              item.endDate = "";
            }
            autoSave();
            this.renderPreview();
          }
        },

        // Setup Sortable.js for drag-and-drop
        setupSortable: function () {
          const lists = [
            "experienceList",
            "educationList",
            "projectsList",
            "certificationsList",
          ];

          lists.forEach((listId) => {
            const el = document.getElementById(listId);
            if (el) {
              Sortable.create(el, {
                handle: ".drag-handle",
                animation: 150,
                onEnd: (evt) => {
                  this.reorderItems(listId, evt.oldIndex, evt.newIndex);
                },
              });
            }
          });
        },

        reorderItems: function (listId, oldIndex, newIndex) {
          const typeMap = {
            experienceList: "experience",
            educationList: "education",
            projectsList: "projects",
            certificationsList: "certifications",
          };

          const type = typeMap[listId];
          const item = CVData[type].splice(oldIndex, 1)[0];
          CVData[type].splice(newIndex, 0, item);

          autoSave();
          this.renderPreview();
        },

        // Magic Wand - Smart Suggestions
        setupMagicWand: function () {
          document
            .getElementById("magicSummary")
            .addEventListener("click", () => {
              const jobTitle = CVData.personal.jobTitle;
              const suggestions = DataManager.getSuggestions(
                "summaries",
                jobTitle
              );
              this.showSuggestions(
                "summarySuggestions",
                suggestions,
                "summary"
              );
            });
        },

        showExperienceSuggestions: function (itemId) {
          const jobTitle = CVData.personal.jobTitle;
          const suggestions = DataManager.getSuggestions(
            "experienceBullets",
            jobTitle
          );
          this.showSuggestions(
            `exp-suggestions-${itemId}`,
            suggestions,
            null,
            "experience",
            itemId
          );
        },

        showSuggestions: function (
          containerId,
          suggestions,
          targetField,
          type,
          itemId
        ) {
          const container = document.getElementById(containerId);

          container.innerHTML = suggestions
            .map(
              (sug, idx) =>
                `<div class="suggestion-item" data-suggestion="${idx}">${sug}</div>`
            )
            .join("");

          container.style.display = "block";

          // Add click handlers
          container.querySelectorAll(".suggestion-item").forEach((el) => {
            el.addEventListener("click", function () {
              const text = this.textContent;

              if (targetField === "summary") {
                document.getElementById("summary").value = text;
                CVData.personal.summary = text;
              } else if (type === "experience") {
                const item = CVData.experience.find((i) => i.id === itemId);
                if (item) {
                  const textarea = document.querySelector(
                    `[data-id="${itemId}"] textarea`
                  );
                  const currentText = textarea.value;
                  const newText = currentText
                    ? currentText + "\n• " + text
                    : "• " + text;
                  textarea.value = newText;
                  item.description = newText;
                }
              }

              autoSave();
              UIManager.renderPreview();
              container.style.display = "none";
            });
          });
        },

        // Template Selection
        setupTemplateSelection: function () {
          const cards = document.querySelectorAll(".template-card");

          cards.forEach((card) => {
            card.addEventListener("click", function () {
              cards.forEach((c) => c.classList.remove("active"));
              this.classList.add("active");

              const template = this.dataset.template;
              CVData.settings.template = template;

              const preview = document.getElementById("cvPreview");
              preview.className = `cv-preview ${template}`;

              autoSave();
              UIManager.renderPreview();
            });
          });
        },

        // Customizer Controls
        setupCustomizer: function () {
          // Color picker
          const colorPicker = document.getElementById("primaryColor");
          const colorValue = document.getElementById("colorValue");

          colorPicker.addEventListener("input", function () {
            CVData.settings.primaryColor = this.value;
            colorValue.textContent = this.value;
            document.documentElement.style.setProperty(
              "--primary-color",
              this.value
            );
            autoSave();
            UIManager.renderPreview();
          });

          // Font pairing
          document
            .getElementById("fontPairing")
            .addEventListener("change", function () {
              CVData.settings.fontPairing = this.value;
              document.getElementById("previewContainer").dataset.font =
                this.value;
              autoSave();
              UIManager.renderPreview();
            });

          // Line spacing
          const lineSpacing = document.getElementById("lineSpacing");
          const lineSpacingValue = document.getElementById("lineSpacingValue");

          lineSpacing.addEventListener("input", function () {
            CVData.settings.lineSpacing = parseFloat(this.value);
            lineSpacingValue.textContent = this.value;
            document.documentElement.style.setProperty(
              "--cv-line-spacing",
              this.value
            );
            autoSave();
          });

          // Margins
          const margins = document.getElementById("margins");
          const marginsValue = document.getElementById("marginsValue");

          margins.addEventListener("input", function () {
            CVData.settings.margins = parseInt(this.value);
            marginsValue.textContent = this.value + "px";
            document.documentElement.style.setProperty(
              "--cv-margins",
              this.value + "px"
            );
            autoSave();
          });

          // Visibility toggles
          [
            "showPhoto",
            "showProjects",
            "showCertifications",
            "showLanguages",
          ].forEach((setting) => {
            document
              .getElementById(setting)
              .addEventListener("change", function () {
                CVData.settings[setting] = this.checked;
                autoSave();
                UIManager.renderPreview();
              });
          });
        },

        // Render CV Preview
        renderPreview: function () {
          const preview = document.getElementById("cvPreview");
          const template = CVData.settings.template;

          preview.className = `cv-preview ${template}`;

          // Call template-specific renderer
          if (template === "silicon-valley") {
            preview.innerHTML = this.renderSiliconValley();
          } else if (template === "wall-street") {
            preview.innerHTML = this.renderWallStreet();
          } else if (template === "portfolio") {
            preview.innerHTML = this.renderPortfolio();
          } else if (template === "entry-level") {
            preview.innerHTML = this.renderEntryLevel();
          }
        },

        // Template Renderers (continued in next part due to length)
        renderSiliconValley: function () {
          const {
            personal,
            experience,
            education,
            skills,
            languages,
            projects,
            certifications,
            settings,
          } = CVData;

          return `
            <div class="cv-sidebar">
                ${
                  settings.showPhoto && personal.photo
                    ? `
                    <div class="cv-photo">
                        <img src="${personal.photo}" alt="${personal.fullName}">
                    </div>
                `
                    : ""
                }
                
                <h1 class="cv-name">${personal.fullName || "Your Name"}</h1>
                <p class="cv-title">${personal.jobTitle || "Your Job Title"}</p>
                
                <div class="cv-contact">
                    <h3 class="cv-section-title">Contact</h3>
                    ${
                      personal.email
                        ? `<div class="cv-contact-item"><i class="fas fa-envelope"></i> ${personal.email}</div>`
                        : ""
                    }
                    ${
                      personal.phone
                        ? `<div class="cv-contact-item"><i class="fas fa-phone"></i> ${personal.phone}</div>`
                        : ""
                    }
                    ${
                      personal.location
                        ? `<div class="cv-contact-item"><i class="fas fa-map-marker-alt"></i> ${personal.location}</div>`
                        : ""
                    }
                    ${
                      personal.linkedin
                        ? `<div class="cv-contact-item"><i class="fab fa-linkedin"></i> ${personal.linkedin}</div>`
                        : ""
                    }
                </div>
                
                ${
                  skills.length > 0
                    ? `
                    <div class="cv-section">
                        <h3 class="cv-section-title">Skills</h3>
                        ${skills
                          .map(
                            (skill) => `
                            <div class="cv-skill-item">
                                <div class="cv-skill-name">
                                    <span>${skill.name}</span>
                                    <span>${skill.level}%</span>
                                </div>
                                <div class="cv-skill-bar">
                                    <div class="cv-skill-bar-fill" style="width: ${skill.level}%"></div>
                                </div>
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
                
                ${
                  settings.showLanguages && languages.length > 0
                    ? `
                    <div class="cv-section">
                        <h3 class="cv-section-title">Languages</h3>
                        ${languages
                          .map(
                            (lang) => `
                            <div class="cv-language-item">
                                <span>${lang.name}</span>
                                <span class="cv-language-level">${lang.level}</span>
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
            </div>
            
            <div class="cv-main">
                ${
                  personal.summary
                    ? `
                    <div class="cv-summary">
                        ${personal.summary}
                    </div>
                `
                    : ""
                }
                
                ${
                  experience.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Experience</h2>
                        ${experience
                          .map(
                            (exp) => `
                            <div class="cv-experience-item">
                                <div class="cv-item-header">
                                    <div>
                                        <div class="cv-item-title">${
                                          exp.title
                                        }</div>
                                        <div class="cv-item-company">${
                                          exp.company
                                        }</div>
                                    </div>
                                    <div class="cv-item-date">${this.formatDate(
                                      exp.startDate
                                    )} - ${
                              exp.current
                                ? "Present"
                                : this.formatDate(exp.endDate)
                            }</div>
                                </div>
                                ${
                                  exp.description
                                    ? `<div class="cv-item-description">${this.formatDescription(
                                        exp.description
                                      )}</div>`
                                    : ""
                                }
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
                
                ${
                  education.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Education</h2>
                        ${education
                          .map(
                            (edu) => `
                            <div class="cv-education-item">
                                <div class="cv-item-header">
                                    <div>
                                        <div class="cv-item-title">${
                                          edu.degree
                                        }</div>
                                        <div class="cv-item-institution">${
                                          edu.institution
                                        }</div>
                                    </div>
                                    <div class="cv-item-date">${this.formatDate(
                                      edu.graduationDate
                                    )}</div>
                                </div>
                                ${
                                  edu.description
                                    ? `<div class="cv-item-description">${edu.description}</div>`
                                    : ""
                                }
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
                
                ${
                  settings.showProjects && projects.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Projects</h2>
                        ${projects
                          .map(
                            (proj) => `
                            <div class="cv-project-item">
                                <div class="cv-item-title">${proj.title}</div>
                                ${
                                  proj.link
                                    ? `<div class="cv-project-link">${proj.link}</div>`
                                    : ""
                                }
                                ${
                                  proj.description
                                    ? `<div class="cv-item-description">${proj.description}</div>`
                                    : ""
                                }
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
            </div>
        `;
        },

        renderWallStreet: function () {
          const {
            personal,
            experience,
            education,
            skills,
            languages,
            projects,
            settings,
          } = CVData;

          return `
            <div class="cv-header">
                <h1 class="cv-name">${personal.fullName || "Your Name"}</h1>
                <p class="cv-title">${personal.jobTitle || "Your Job Title"}</p>
                <div class="cv-contact">
                    ${
                      personal.email
                        ? `<span class="cv-contact-item">${personal.email}</span>`
                        : ""
                    }
                    ${
                      personal.phone
                        ? `<span class="cv-contact-item">${personal.phone}</span>`
                        : ""
                    }
                    ${
                      personal.location
                        ? `<span class="cv-contact-item">${personal.location}</span>`
                        : ""
                    }
                    ${
                      personal.linkedin
                        ? `<span class="cv-contact-item">${personal.linkedin}</span>`
                        : ""
                    }
                </div>
            </div>
            
            ${
              personal.summary
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title">Professional Summary</h2>
                    <div class="cv-summary">${personal.summary}</div>
                </div>
            `
                : ""
            }
            
            ${
              experience.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title">Experience</h2>
                    ${experience
                      .map(
                        (exp) => `
                        <div class="cv-experience-item">
                            <div class="cv-item-header">
                                <span class="cv-item-title">${exp.title}</span>
                                <span class="cv-item-company">${
                                  exp.company
                                }</span>
                            </div>
                            <div class="cv-item-date">${this.formatDate(
                              exp.startDate
                            )} - ${
                          exp.current ? "Present" : this.formatDate(exp.endDate)
                        }</div>
                            ${
                              exp.description
                                ? `<div class="cv-item-description">${this.formatDescription(
                                    exp.description
                                  )}</div>`
                                : ""
                            }
                        </div>
                    `
                      )
                      .join("")}
                </div>
            `
                : ""
            }
            
            ${
              education.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title">Education</h2>
                    ${education
                      .map(
                        (edu) => `
                        <div class="cv-education-item">
                            <div class="cv-item-header">
                                <span class="cv-item-title">${edu.degree}</span>
                                <span class="cv-item-institution">${
                                  edu.institution
                                }</span>
                            </div>
                            <div class="cv-item-date">${this.formatDate(
                              edu.graduationDate
                            )}</div>
                        </div>
                    `
                      )
                      .join("")}
                </div>
            `
                : ""
            }
            
            ${
              skills.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title">Skills</h2>
                    <div class="cv-skills-grid">
                        ${skills
                          .map(
                            (skill) =>
                              `<div class="cv-skill-item">${skill.name}</div>`
                          )
                          .join("")}
                    </div>
                </div>
            `
                : ""
            }
        `;
        },

        renderPortfolio: function () {
          const {
            personal,
            experience,
            education,
            projects,
            skills,
            settings,
          } = CVData;

          return `
            <div class="cv-header">
                ${
                  settings.showPhoto && personal.photo
                    ? `
                    <div class="cv-photo">
                        <img src="${personal.photo}" alt="${personal.fullName}">
                    </div>
                `
                    : ""
                }
                <h1 class="cv-name">${personal.fullName || "Your Name"}</h1>
                <p class="cv-title">${personal.jobTitle || "Your Job Title"}</p>
                <div class="cv-contact">
                    ${
                      personal.email
                        ? `<span class="cv-contact-item"><i class="fas fa-envelope"></i> ${personal.email}</span>`
                        : ""
                    }
                    ${
                      personal.phone
                        ? `<span class="cv-contact-item"><i class="fas fa-phone"></i> ${personal.phone}</span>`
                        : ""
                    }
                    ${
                      personal.location
                        ? `<span class="cv-contact-item"><i class="fas fa-map-marker-alt"></i> ${personal.location}</span>`
                        : ""
                    }
                    ${
                      personal.linkedin
                        ? `<span class="cv-contact-item"><i class="fab fa-linkedin"></i> ${personal.linkedin}</span>`
                        : ""
                    }
                </div>
            </div>
            
            <div class="cv-content">
                ${
                  personal.summary
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">About</h2>
                        <div class="cv-summary">${personal.summary}</div>
                    </div>
                `
                    : ""
                }
                
                ${
                  settings.showProjects && projects.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Featured Projects</h2>
                        <div class="cv-projects-grid">
                            ${projects
                              .map(
                                (proj) => `
                                <div class="cv-project-card">
                                    <div class="cv-project-title">${
                                      proj.title
                                    }</div>
                                    ${
                                      proj.link
                                        ? `<a href="${proj.link}" class="cv-project-link">${proj.link}</a>`
                                        : ""
                                    }
                                    <div class="cv-project-description">${
                                      proj.description
                                    }</div>
                                </div>
                            `
                              )
                              .join("")}
                        </div>
                    </div>
                `
                    : ""
                }
                
                ${
                  experience.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Experience</h2>
                        ${experience
                          .map(
                            (exp) => `
                            <div class="cv-experience-item">
                                <div class="cv-item-header">
                                    <div>
                                        <div class="cv-item-title">${
                                          exp.title
                                        }</div>
                                        <div class="cv-item-company">${
                                          exp.company
                                        }</div>
                                        <div class="cv-item-date">${this.formatDate(
                                          exp.startDate
                                        )} - ${
                              exp.current
                                ? "Present"
                                : this.formatDate(exp.endDate)
                            }</div>
                                    </div>
                                </div>
                                ${
                                  exp.description
                                    ? `<div class="cv-item-description">${this.formatDescription(
                                        exp.description
                                      )}</div>`
                                    : ""
                                }
                            </div>
                        `
                          )
                          .join("")}
                    </div>
                `
                    : ""
                }
                
                ${
                  skills.length > 0
                    ? `
                    <div class="cv-section">
                        <h2 class="cv-section-title">Skills</h2>
                        <div class="cv-skills-flex">
                            ${skills
                              .map(
                                (skill) =>
                                  `<div class="cv-skill-tag">${skill.name}</div>`
                              )
                              .join("")}
                        </div>
                    </div>
                `
                    : ""
                }
            </div>
        `;
        },

        renderEntryLevel: function () {
          const {
            personal,
            experience,
            education,
            skills,
            projects,
            certifications,
            settings,
          } = CVData;

          return `
            <div class="cv-header">
                ${
                  settings.showPhoto && personal.photo
                    ? `
                    <div class="cv-photo">
                        <img src="${personal.photo}" alt="${personal.fullName}">
                    </div>
                `
                    : ""
                }
                <h1 class="cv-name">${personal.fullName || "Your Name"}</h1>
                <p class="cv-title">${personal.jobTitle || "Your Job Title"}</p>
                <div class="cv-contact">
                    ${
                      personal.email
                        ? `<span class="cv-contact-item"><i class="fas fa-envelope"></i> ${personal.email}</span>`
                        : ""
                    }
                    ${
                      personal.phone
                        ? `<span class="cv-contact-item"><i class="fas fa-phone"></i> ${personal.phone}</span>`
                        : ""
                    }
                    ${
                      personal.location
                        ? `<span class="cv-contact-item"><i class="fas fa-map-marker-alt"></i> ${personal.location}</span>`
                        : ""
                    }
                    ${
                      personal.linkedin
                        ? `<span class="cv-contact-item"><i class="fab fa-linkedin"></i> ${personal.linkedin}</span>`
                        : ""
                    }
                </div>
            </div>
            
            ${
              personal.summary
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title"><i class="fas fa-user"></i> Profile</h2>
                    <div class="cv-summary">${personal.summary}</div>
                </div>
            `
                : ""
            }
            
            ${
              education.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title"><i class="fas fa-graduation-cap"></i> Education</h2>
                    ${education
                      .map(
                        (edu) => `
                        <div class="cv-education-item">
                            <div class="cv-item-header">
                                <div>
                                    <div class="cv-item-title">${
                                      edu.degree
                                    }</div>
                                    <div class="cv-item-institution">${
                                      edu.institution
                                    }</div>
                                    <div class="cv-item-date">${this.formatDate(
                                      edu.graduationDate
                                    )}</div>
                                </div>
                            </div>
                            ${
                              edu.description
                                ? `<div class="cv-item-description">${edu.description}</div>`
                                : ""
                            }
                        </div>
                    `
                      )
                      .join("")}
                </div>
            `
                : ""
            }
            
            ${
              skills.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title"><i class="fas fa-code"></i> Skills</h2>
                    <div class="cv-skills-container">
                        <div class="cv-skill-category">
                            <div class="cv-skill-category-title">Technical Skills</div>
                            <div class="cv-skill-list">
                                ${skills
                                  .map(
                                    (skill) =>
                                      `<div class="cv-skill-item">${skill.name}</div>`
                                  )
                                  .join("")}
                            </div>
                        </div>
                    </div>
                </div>
            `
                : ""
            }
            
            ${
              experience.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title"><i class="fas fa-briefcase"></i> Experience</h2>
                    ${experience
                      .map(
                        (exp) => `
                        <div class="cv-experience-item">
                            <div class="cv-item-header">
                                <div>
                                    <div class="cv-item-title">${
                                      exp.title
                                    }</div>
                                    <div class="cv-item-company">${
                                      exp.company
                                    }</div>
                                    <div class="cv-item-date">${this.formatDate(
                                      exp.startDate
                                    )} - ${
                          exp.current ? "Present" : this.formatDate(exp.endDate)
                        }</div>
                                </div>
                            </div>
                            ${
                              exp.description
                                ? `<div class="cv-item-description">${this.formatDescription(
                                    exp.description
                                  )}</div>`
                                : ""
                            }
                        </div>
                    `
                      )
                      .join("")}
                </div>
            `
                : ""
            }
            
            ${
              settings.showProjects && projects.length > 0
                ? `
                <div class="cv-section">
                    <h2 class="cv-section-title"><i class="fas fa-project-diagram"></i> Projects</h2>
                    ${projects
                      .map(
                        (proj) => `
                        <div class="cv-project-item">
                            <div class="cv-project-title">${proj.title}</div>
                            ${
                              proj.link
                                ? `<a href="${proj.link}" class="cv-project-link">${proj.link}</a>`
                                : ""
                            }
                            <div class="cv-project-description">${
                              proj.description
                            }</div>
                        </div>
                    `
                      )
                      .join("")}
                </div>
            `
                : ""
            }
        `;
        },

        // Utility functions
        formatDate: function (dateStr) {
          if (!dateStr) return "";
          const date = new Date(dateStr);
          return date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
          });
        },

        formatDescription: function (text) {
          if (!text) return "";

          // Check if text contains bullet points
          if (text.includes("•") || text.includes("-")) {
            const lines = text.split("\n").filter((line) => line.trim());
            const bullets = lines.filter(
              (line) =>
                line.trim().startsWith("•") || line.trim().startsWith("-")
            );
            const regular = lines.filter(
              (line) =>
                !line.trim().startsWith("•") && !line.trim().startsWith("-")
            );

            let html = "";
            if (regular.length > 0) {
              html += "<p>" + regular.join(" ") + "</p>";
            }
            if (bullets.length > 0) {
              html += "<ul>";
              bullets.forEach((bullet) => {
                html += "<li>" + bullet.replace(/^[•\-]\s*/, "") + "</li>";
              });
              html += "</ul>";
            }
            return html;
          }

          return "<p>" + text.replace(/\n/g, "<br>") + "</p>";
        },

        // Load saved data into UI
        loadSavedData: function () {
          const {
            personal,
            experience,
            education,
            skills,
            languages,
            projects,
            certifications,
            settings,
          } = CVData;

          // Load personal info
          if (personal.fullName)
            document.getElementById("fullName").value = personal.fullName;
          if (personal.jobTitle)
            document.getElementById("jobTitle").value = personal.jobTitle;
          if (personal.email)
            document.getElementById("email").value = personal.email;
          if (personal.phone)
            document.getElementById("phone").value = personal.phone;
          if (personal.location)
            document.getElementById("location").value = personal.location;
          if (personal.linkedin)
            document.getElementById("linkedin").value = personal.linkedin;
          if (personal.summary)
            document.getElementById("summary").value = personal.summary;

          if (personal.photo) {
            document.getElementById(
              "photoPreview"
            ).innerHTML = `<img src="${personal.photo}" alt="Profile Photo">`;
          }

          // Load lists
          experience.forEach((item) => this.addExperienceItem(item));
          education.forEach((item) => this.addEducationItem(item));
          skills.forEach((item) => this.renderSkillItem(item));
          languages.forEach((item) => this.renderLanguageItem(item));
          projects.forEach((item) => this.addProjectItem(item));
          certifications.forEach((item) => this.addCertificationItem(item));

          // Load settings
          document.getElementById("primaryColor").value = settings.primaryColor;
          document.getElementById("colorValue").textContent =
            settings.primaryColor;
          document.getElementById("fontPairing").value = settings.fontPairing;
          document.getElementById("lineSpacing").value = settings.lineSpacing;
          document.getElementById("lineSpacingValue").textContent =
            settings.lineSpacing;
          document.getElementById("margins").value = settings.margins;
          document.getElementById("marginsValue").textContent =
            settings.margins + "px";
          document.getElementById("showPhoto").checked = settings.showPhoto;
          document.getElementById("showProjects").checked =
            settings.showProjects;
          document.getElementById("showCertifications").checked =
            settings.showCertifications;
          document.getElementById("showLanguages").checked =
            settings.showLanguages;

          // Apply settings
          document.documentElement.style.setProperty(
            "--primary-color",
            settings.primaryColor
          );
          document.documentElement.style.setProperty(
            "--cv-line-spacing",
            settings.lineSpacing
          );
          document.documentElement.style.setProperty(
            "--cv-margins",
            settings.margins + "px"
          );
          document.getElementById("previewContainer").dataset.font =
            settings.fontPairing;

          // Set active template
          document.querySelectorAll(".template-card").forEach((card) => {
            card.classList.remove("active");
            if (card.dataset.template === settings.template) {
              card.classList.add("active");
            }
          });

          this.renderPreview();
        },
      };

      // Initialize UI when DOM is ready
      document.addEventListener("DOMContentLoaded", function () {
        UIManager.init();
      });
      /* ===================================
   DEBDEX ULTRA - EXPORT FUNCTIONALITY
   PDF and JSON Export Logic
   =================================== */

      const ExportManager = {
        // Export to PDF
        exportPDF: function () {
          const preview = document.getElementById("cvPreview");
          const fileName = `${
            CVData.personal.fullName.replace(/\s+/g, "-").toLowerCase() || "cv"
          }-${Date.now()}.pdf`;

          // Show loading indicator
          this.showLoadingOverlay("Generating PDF...");

          // Configure PDF options
          const opt = {
            margin: 0,
            filename: fileName,
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: {
              scale: 2,
              useCORS: true,
              logging: false,
              letterRendering: true,
              backgroundColor: "#ffffff",
            },
            jsPDF: {
              unit: "mm",
              format: "a4",
              orientation: "portrait",
              compress: true,
            },
            pagebreak: {
              mode: ["avoid-all", "css", "legacy"],
              before: ".cv-section",
              after: ".cv-section",
            },
          };

          // Generate PDF
          html2pdf()
            .set(opt)
            .from(preview)
            .save()
            .then(() => {
              this.hideLoadingOverlay();
              this.showNotification("PDF exported successfully! ✅", "success");
            })
            .catch((error) => {
              console.error("PDF export error:", error);
              this.hideLoadingOverlay();
              this.showNotification(
                "Failed to export PDF. Please try again. ❌",
                "error"
              );
            });
        },

        // Export to JSON
        exportJSON: function () {
          try {
            DataManager.exportJSON();
            this.showNotification("JSON exported successfully! ✅", "success");
          } catch (error) {
            console.error("JSON export error:", error);
            this.showNotification(
              "Failed to export JSON. Please try again. ❌",
              "error"
            );
          }
        },

        // Import from JSON
        importJSON: function () {
          const fileInput = document.getElementById("jsonFileInput");

          fileInput.onchange = function (e) {
            const file = e.target.files[0];
            if (!file) return;

            if (!file.name.endsWith(".json")) {
              ExportManager.showNotification(
                "Please select a valid JSON file. ❌",
                "error"
              );
              return;
            }

            ExportManager.showLoadingOverlay("Importing data...");

            DataManager.importJSON(file)
              .then(() => {
                // Reload UI with imported data
                ExportManager.reloadUI();
                ExportManager.hideLoadingOverlay();
                ExportManager.showNotification(
                  "Data imported successfully! ✅",
                  "success"
                );
              })
              .catch((error) => {
                console.error("Import error:", error);
                ExportManager.hideLoadingOverlay();
                ExportManager.showNotification(
                  "Failed to import JSON. Invalid file format. ❌",
                  "error"
                );
              });

            // Reset file input
            fileInput.value = "";
          };

          fileInput.click();
        },

        // Reload UI after import
        reloadUI: function () {
          // Clear existing lists
          document.getElementById("experienceList").innerHTML = "";
          document.getElementById("educationList").innerHTML = "";
          document.getElementById("skillsList").innerHTML = "";
          document.getElementById("languagesList").innerHTML = "";
          document.getElementById("projectsList").innerHTML = "";
          document.getElementById("certificationsList").innerHTML = "";

          // Reload data
          UIManager.loadSavedData();

          // Re-setup sortable
          UIManager.setupSortable();
        },

        // Show loading overlay
        showLoadingOverlay: function (message) {
          // Remove existing overlay if any
          this.hideLoadingOverlay();

          const overlay = document.createElement("div");
          overlay.id = "loadingOverlay";
          overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(5px);
        `;

          overlay.innerHTML = `
            <div style="
                background: white;
                padding: 40px 60px;
                border-radius: 16px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            ">
                <div style="
                    width: 50px;
                    height: 50px;
                    border: 5px solid #f3f3f3;
                    border-top: 5px solid var(--primary-color, #4f46e5);
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin: 0 auto 20px;
                "></div>
                <p style="
                    font-size: 1.1rem;
                    font-weight: 600;
                    color: #333;
                    margin: 0;
                ">${message}</p>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;

          document.body.appendChild(overlay);
        },

        // Hide loading overlay
        hideLoadingOverlay: function () {
          const overlay = document.getElementById("loadingOverlay");
          if (overlay) {
            overlay.remove();
          }
        },

        // Show notification
        showNotification: function (message, type = "info") {
          // Remove existing notifications
          const existing = document.querySelectorAll(".notification");
          existing.forEach((n) => n.remove());

          const notification = document.createElement("div");
          notification.className = "notification";

          const colors = {
            success: "#10b981",
            error: "#ef4444",
            info: "#4f46e5",
            warning: "#f59e0b",
          };

          const icons = {
            success: "fa-check-circle",
            error: "fa-exclamation-circle",
            info: "fa-info-circle",
            warning: "fa-exclamation-triangle",
          };

          notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            color: #333;
            padding: 18px 24px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            border-left: 4px solid ${colors[type]};
            animation: slideIn 0.3s ease;
            max-width: 400px;
        `;

          notification.innerHTML = `
            <i class="fas ${icons[type]}" style="color: ${colors[type]}; font-size: 1.3rem;"></i>
            <span>${message}</span>
            <style>
                @keyframes slideIn {
                    from {
                        transform: translateX(400px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                @keyframes slideOut {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(400px);
                        opacity: 0;
                    }
                }
            </style>
        `;

          document.body.appendChild(notification);

          // Auto-remove after 4 seconds
          setTimeout(() => {
            notification.style.animation = "slideOut 0.3s ease";
            setTimeout(() => notification.remove(), 300);
          }, 4000);
        },

        // Print preview (alternative to PDF export)
        printPreview: function () {
          window.print();
        },

        // Generate shareable link (future feature)
        generateShareableLink: function () {
          // Encode CV data
          const encoded = btoa(JSON.stringify(CVData));
          const url = `${window.location.origin}${window.location.pathname}?data=${encoded}`;

          // Copy to clipboard
          navigator.clipboard
            .writeText(url)
            .then(() => {
              this.showNotification(
                "Shareable link copied to clipboard! 🔗",
                "success"
              );
            })
            .catch(() => {
              this.showNotification("Failed to copy link. ❌", "error");
            });
        },

        // Load from shareable link
        loadFromURL: function () {
          const params = new URLSearchParams(window.location.search);
          const data = params.get("data");

          if (data) {
            try {
              const decoded = JSON.parse(atob(data));
              Object.assign(CVData, decoded);
              DataManager.save();
              this.showNotification("CV loaded from link! ✅", "success");
              return true;
            } catch (error) {
              console.error("Failed to load from URL:", error);
              this.showNotification("Invalid link data. ❌", "error");
              return false;
            }
          }
          return false;
        },
      };

      // Initialize export buttons
      document.addEventListener("DOMContentLoaded", function () {
        // PDF Export
        document
          .getElementById("exportPdfBtn")
          .addEventListener("click", function () {
            if (!CVData.personal.fullName) {
              ExportManager.showNotification(
                "Please add your name first! ⚠️",
                "warning"
              );
              return;
            }
            ExportManager.exportPDF();
          });

        // JSON Export
        document
          .getElementById("exportJsonBtn")
          .addEventListener("click", function () {
            ExportManager.exportJSON();
          });

        // JSON Import
        document
          .getElementById("importBtn")
          .addEventListener("click", function () {
            ExportManager.importJSON();
          });

        // Check for URL data on load
        ExportManager.loadFromURL();
      });
      /* ===================================
   DEBDEX ULTRA - MAIN APP CONTROLLER
   Application Initialization and Coordination
   =================================== */

      const DebdexApp = {
        version: "1.0.0",

        // Initialize the application
        init: function () {
          console.log(
            `%cDebdex Ultra v${this.version}`,
            "font-size: 20px; font-weight: bold; color: #4f46e5;"
          );
          console.log(
            "%c🚀 Premium CV Builder Initialized",
            "font-size: 14px; color: #10b981;"
          );

          // Load saved data first
          DataManager.load();

          // Initialize UI components
          this.setupKeyboardShortcuts();
          this.setupAutoSave();
          this.setupPWA();
          this.checkBrowserCompatibility();
          this.setupTour();

          // Performance monitoring
          this.monitorPerformance();
        },

        // Keyboard shortcuts
        setupKeyboardShortcuts: function () {
          document.addEventListener("keydown", function (e) {
            // Ctrl/Cmd + S: Save (actually auto-saves, but show confirmation)
            if ((e.ctrlKey || e.metaKey) && e.key === "s") {
              e.preventDefault();
              DataManager.save();
              ExportManager.showNotification("CV data saved! 💾", "success");
            }

            // Ctrl/Cmd + P: Print/Export PDF
            if ((e.ctrlKey || e.metaKey) && e.key === "p") {
              e.preventDefault();
              ExportManager.exportPDF();
            }

            // Ctrl/Cmd + E: Export JSON
            if ((e.ctrlKey || e.metaKey) && e.key === "e") {
              e.preventDefault();
              ExportManager.exportJSON();
            }

            // Ctrl/Cmd + I: Import JSON
            if ((e.ctrlKey || e.metaKey) && e.key === "i") {
              e.preventDefault();
              ExportManager.importJSON();
            }

            // Ctrl/Cmd + D: Toggle Dark Mode
            if ((e.ctrlKey || e.metaKey) && e.key === "d") {
              e.preventDefault();
              document.getElementById("darkModeToggle").click();
            }
          });
        },

        // Enhanced auto-save with status indicator
        setupAutoSave: function () {
          let saveIndicator = null;

          // Create save indicator
          const createIndicator = () => {
            if (saveIndicator) return;

            saveIndicator = document.createElement("div");
            saveIndicator.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: rgba(16, 185, 129, 0.9);
                color: white;
                padding: 10px 16px;
                border-radius: 8px;
                font-size: 0.85rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                z-index: 9999;
                animation: fadeInOut 2s ease;
            `;

            saveIndicator.innerHTML = `
                <i class="fas fa-check-circle"></i>
                <span>Saved</span>
                <style>
                    @keyframes fadeInOut {
                        0%, 100% { opacity: 0; transform: translateY(10px); }
                        10%, 90% { opacity: 1; transform: translateY(0); }
                    }
                </style>
            `;

            document.body.appendChild(saveIndicator);

            setTimeout(() => {
              if (saveIndicator) {
                saveIndicator.remove();
                saveIndicator = null;
              }
            }, 2000);
          };

          // Override autoSave to show indicator
          const originalAutoSave = window.autoSave;
          window.autoSave = function () {
            originalAutoSave();
            createIndicator();
          };
        },

        // PWA setup (Progressive Web App)
        setupPWA: function () {
          if ("serviceWorker" in navigator) {
            // Register service worker (if you want to make it a PWA)
            // navigator.serviceWorker.register('/sw.js');
          }

          // Add to home screen prompt
          let deferredPrompt;

          window.addEventListener("beforeinstallprompt", (e) => {
            e.preventDefault();
            deferredPrompt = e;

            // Show install button (could add to UI later)
            console.log("💡 App can be installed!");
          });
        },

        // Browser compatibility check
        checkBrowserCompatibility: function () {
          const features = {
            localStorage: typeof Storage !== "undefined",
            canvas: !!document.createElement("canvas").getContext,
            fileReader: typeof FileReader !== "undefined",
            fetch: typeof fetch !== "undefined",
          };

          const unsupported = Object.keys(features).filter(
            (key) => !features[key]
          );

          if (unsupported.length > 0) {
            console.warn("⚠️ Unsupported features:", unsupported);
            ExportManager.showNotification(
              "Some features may not work in your browser. Please use a modern browser. ⚠️",
              "warning"
            );
          }
        },

        // First-time user tour
        setupTour: function () {
          const hasSeenTour = localStorage.getItem("debdex_tour_seen");

          if (!hasSeenTour && !window.location.search.includes("data=")) {
            // Show welcome message
            setTimeout(() => {
              this.showWelcomeModal();
            }, 1000);
          }
        },

        showWelcomeModal: function () {
          const modal = document.createElement("div");
          modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        `;

          modal.innerHTML = `
            <div style="
                background: white;
                padding: 50px;
                border-radius: 20px;
                max-width: 600px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            ">
                <div style="font-size: 4rem; margin-bottom: 20px;">🚀</div>
                <h1 style="
                    font-size: 2rem;
                    margin-bottom: 15px;
                    color: #1a1a1a;
                    font-weight: 800;
                ">Welcome to Debdex<span style="color: #4f46e5;">CV Maker</span></h1>
                <p style="
                    font-size: 1.1rem;
                    color: #666;
                    line-height: 1.6;
                    margin-bottom: 30px;
                ">
                    The premium CV builder designed to help you get hired. 
                    Build professional resumes with ATS optimization, smart suggestions, 
                    and beautiful templates.
                </p>
                <div style="
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 20px;
                    margin-bottom: 30px;
                    text-align: left;
                ">
                    <div style="padding: 15px; background: #f9f9f9; border-radius: 12px;">
                        <div style="font-size: 1.5rem; margin-bottom: 8px;">🤖</div>
                        <strong style="color: #333;">ATS Scanner</strong>
                        <p style="font-size: 0.85rem; color: #666; margin: 5px 0 0;">
                            Optimize for applicant tracking systems
                        </p>
                    </div>
                    <div style="padding: 15px; background: #f9f9f9; border-radius: 12px;">
                        <div style="font-size: 1.5rem; margin-bottom: 8px;">✨</div>
                        <strong style="color: #333;">Smart Suggestions</strong>
                        <p style="font-size: 0.85rem; color: #666; margin: 5px 0 0;">
                            AI-powered content recommendations
                        </p>
                    </div>
                    <div style="padding: 15px; background: #f9f9f9; border-radius: 12px;">
                        <div style="font-size: 1.5rem; margin-bottom: 8px;">🎨</div>
                        <strong style="color: #333;">4 Pro Templates</strong>
                        <p style="font-size: 0.85rem; color: #666; margin: 5px 0 0;">
                            Beautiful, industry-specific designs
                        </p>
                    </div>
                    <div style="padding: 15px; background: #f9f9f9; border-radius: 12px;">
                        <div style="font-size: 1.5rem; margin-bottom: 8px;">💾</div>
                        <strong style="color: #333;">Auto-Save</strong>
                        <p style="font-size: 0.85rem; color: #666; margin: 5px 0 0;">
                            Never lose your progress
                        </p>
                    </div>
                </div>
<style>
  .btn-start-53 {
    margin-top: 20px;
    background-color: #3DD1E7;
    border: 0 solid #E5E7EB;
    box-sizing: border-box;
    color: #000000;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    font-size: 1rem;
    font-weight: 700;
    line-height: 1.75rem;
    padding: .75rem 1.65rem;
    position: relative;
    text-align: center;
    text-decoration: none;
    width: auto;
    cursor: pointer;
    transform: rotate(-2deg);
    user-select: none;
    touch-action: manipulation;
  }

  .btn-start-53:focus {
    outline: 0;
  }

  /* The Black Offset Border */
  .btn-start-53:after {
    content: '';
    position: absolute;
    border: 1px solid #000000;
    bottom: 4px;
    left: 4px;
    width: calc(100% - 1px);
    height: calc(100% - 1px);
    transition: all 0.2s ease;
  }

  /* Hover Effect */
  .btn-start-53:hover:after {
    bottom: 2px;
    left: 2px;
  }

  @media (min-width: 768px) {
    .btn-start-53 {
      padding: .75rem 3rem;
      font-size: 1.25rem;
    }
  }
</style>

<button class="btn-start-53" onclick="DebdexApp.closeWelcome()">
  Get Started →
</button>
                <p style="
                    font-size: 0.85rem;
                    color: #999;
                    margin-top: 20px;
                ">
                    💡 Tip: Press <kbd>Ctrl+S</kbd> to save, <kbd>Ctrl+P</kbd> to export PDF
                </p>
            </div>
        `;

          document.body.appendChild(modal);
          window.welcomeModal = modal;
        },

        closeWelcome: function () {
          localStorage.setItem("debdex_tour_seen", "true");
          const modal = window.welcomeModal;
          if (modal) {
            modal.style.animation = "fadeOut 0.3s ease";
            setTimeout(() => modal.remove(), 300);
          }
        },

        // Performance monitoring
        monitorPerformance: function () {
          if ("performance" in window) {
            window.addEventListener("load", () => {
              setTimeout(() => {
                const perfData = performance.getEntriesByType("navigation")[0];
                if (perfData) {
                  const loadTime =
                    perfData.loadEventEnd - perfData.loadEventStart;
                  console.log(`⚡ Page loaded in ${loadTime.toFixed(2)}ms`);
                }
              }, 0);
            });
          }
        },

        // Reset application (for demo purposes)
        reset: function () {
          if (confirm("⚠️ This will delete all your CV data. Are you sure?")) {
            localStorage.clear();
            location.reload();
          }
        },

        // Get app statistics
        getStats: function () {
          return {
            version: this.version,
            dataSize: new Blob([JSON.stringify(CVData)]).size,
            sections: {
              experience: CVData.experience.length,
              education: CVData.education.length,
              skills: CVData.skills.length,
              projects: CVData.projects.length,
              certifications: CVData.certifications.length,
            },
            template: CVData.settings.template,
            lastModified: localStorage.getItem("debdex_last_save") || "Unknown",
          };
        },
      };

      // Initialize app when DOM is ready
      document.addEventListener("DOMContentLoaded", function () {
        DebdexApp.init();
      });

      // Global error handler
      window.addEventListener("error", function (e) {
        console.error("Application error:", e.error);
        ExportManager.showNotification(
          "An error occurred. Your data is safe. 🛡️",
          "error"
        );
      });

      // Before unload warning (if there are unsaved changes)
      window.addEventListener("beforeunload", function (e) {
        // Always save before leaving
        DataManager.save();
      });

      // Expose app to console for debugging
      window.Debdex = DebdexApp;

      // Console welcome message
      console.log(
        "%c",
        "padding: 40px 100px; background: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 50'%3E%3Ctext x='10' y='35' font-family='Arial' font-weight='bold' font-size='24' fill='%234f46e5'%3EDebdex Ultra%3C/text%3E%3C/svg%3E\") no-repeat;"
      );
      console.log(
        "%cDebug Commands:",
        "font-weight: bold; font-size: 14px; color: #4f46e5;"
      );
      console.log("%cDebdex.getStats() - View app statistics", "color: #666;");
      console.log("%cDebdex.reset() - Clear all data", "color: #666;");
      console.log("%cCVData - View current CV data", "color: #666;");